  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyCjJ62m4i0A5iHldM4q2-pBn2A1rAYyUYA",
    authDomain: "energy-aad4e.firebaseapp.com",
    databaseURL: "https://energy-aad4e.firebaseio.com",
    projectId: "energy-aad4e",
    storageBucket: "energy-aad4e.appspot.com",
    messagingSenderId: "95226725829",
    appId: "1:95226725829:web:bf39d8ccfcd05117fcf7ac"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);